var posts = require('../db/posts');
var helpers = require('../helpers');
var path = require('path');
var sharp = require('sharp');
var nanoid = require('nanoid');

var getAllPosts = posts.getAllPosts;
var createPost = posts.createPost;
var getPostById = posts.getPostById;
var deletePostById = posts.deletePostById;
var generateError = helpers.generateError;
var createPathIfNotExists = helpers.createPathIfNotExists;

var getPostsController = function(req, res, next) {
  try {
    var posts = getAllPosts();
    res.send({
      status: 'ok',
      data: posts,
    });
  } catch (error) {
    next(error);
  }
};

var newPostController = function(req, res, next) {
  try {
    var text = req.body.text;

    if (!text || text.length > 280) {
      throw generateError(
        'El texto del post debe existir y ser menor de 280 caracteres',
        400
      );
    }
    var imageFileName;

    if (req.files && req.files.image) {
      var uploadsDir = path.join(__dirname, '../uploads');
      createPathIfNotExists(uploadsDir);
      var image = sharp(req.files.image.data);
      image.resize(1000);
      imageFileName = `${nanoid(24)}.jpg`;
      image.toFile(path.join(uploadsDir, imageFileName));
    }

    var id = createPost(req.userId, text, imageFileName);

    res.send({
      status: 'ok',
      message: `Post con id: ${id} creado correctamente`,
    });
  } catch (error) {
    next(error);
  }
};

// Resto de controladores (getSinglePostController y deletePostController)

module.exports = {
  getPostsController: getPostsController,
  newPostController: newPostController,
  // Otros controladores exportados
};
