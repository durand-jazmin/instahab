var bcrypt = require('bcrypt');
var jwt = require('jsonwebtoken');
var helpers = require('../helpers');
var usersDB = require('../db/users');

var newUserController = function(req, res, next) {
  try {
    var email = req.body.email;
    var password = req.body.password;

    // Esto debería ser sustituido por joi
    if (!email || !password) {
      throw helpers.generateError('Debes enviar un email y una password', 400);
    }

    var id = usersDB.createUser(email, password);

    res.send({
      status: 'ok',
      message: 'User created with id: ' + id,
    });
  } catch (error) {
    next(error);
  }
};

var getUserController = function(req, res, next) {
  try {
    var id = req.params.id;

    var user = usersDB.getUserById(id);

    res.send({
      status: 'ok',
      data: user,
    });
  } catch (error) {
    next(error);
  }
};

var loginController = function(req, res, next) {
  try {
    var email = req.body.email;
    var password = req.body.password;

    if (!email || !password) {
      throw helpers.generateError('Debes enviar un email y una password', 400);
    }

    // Recojo los datos de la base de datos del usuario con ese mail
    var user = usersDB.getUserByEmail(email);

    // Compruebo que las contraseñas coinciden
    var validPassword = bcrypt.compareSync(password, user.password);

    if (!validPassword) {
      throw helpers.generateError('La contraseña no coincide', 401);
    }

    // Creo el payload del token
    var payload = { id: user.id };

    // Firmo el token
    var token = jwt.sign(payload, process.env.SECRET, {
      expiresIn: '30d',
    });

    // Envío el token
    res.send({
      status: 'ok',
      data: token,
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  newUserController: newUserController,
  getUserController: getUserController,
  loginController: loginController,
};
